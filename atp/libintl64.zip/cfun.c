    double CFUN(double arg[])
    { arg[0] = arg[0] + arg[1];
      arg[1] = 10 * arg[0];
      return 2;
    }
