const data = { name: "John", age: 30 };

fetch("https://example.com/api", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify(data),
})
  .then((response) => response.json())
  .then((result) => console.log(result))
  .catch((error) => console.error("Error:", error));





fetch('/cart', {
    method:'post',
    headers:{
        "Accept": "application/json, text/plain, */*",
        "Content-type": "application/json; charset = UTF-8"
    },
    body: JSON.stringify(selected),
})
.then(res => {
    if (!res.ok) {                                   // ***
        throw new Error("HTTP error " + res.status); // *** #1
    }                                                // ***
    return res.json();                               // *** #2
})
.then(data => {
    // *** Use `data` here
})
.catch(error => {
    // *** Handle/report error here                  // *** #3
});


Server-Sent Events (SSE) is a technology that allows a server to push real-time updates to a client over a single HTTP connection. Below is an example of how to implement SSE in C:

Server-Side Implementation in C

Here’s a basic example of how to create a server that sends SSE updates:

Copiar o código
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 8080

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    char *header = "HTTP/1.1 200 OK\r\n"
                   "Content-Type: text/event-stream\r\n"
                   "Cache-Control: no-cache\r\n"
                   "Connection: keep-alive\r\n\r\n";

    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        perror("Socket failed");
        return 1;
    }

    // Bind socket
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        return 1;
    }

    // Listen for connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        return 1;
    }

    printf("Server listening on port %d...\n", PORT);

    // Accept connection
    new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
    if (new_socket < 0) {
        perror("Accept failed");
        return 1;
    }

    // Send HTTP headers
    send(new_socket, header, strlen(header), 0);

    // Send events
    for (int i = 0; i < 10; i++) {
        char buffer[128];
        snprintf(buffer, sizeof(buffer), "data: Message %d\n\n", i + 1);
        send(new_socket, buffer, strlen(buffer), 0);
        sleep(1); // Simulate delay between events
    }

    close(new_socket);
    close(server_fd);
    return 0;
}

Explanation
HTTP Headers: The server sends headers to indicate the response is an SSE stream (Content-Type: text/event-stream).
Event Format: Each event is sent as data: <message>\n\n. The double newline separates events.
Connection: The connection remains open, allowing the server to push updates continuously.
Client-Side Example

On the client side (e.g., in JavaScript), you can listen to these events:

Copiar o código
const eventSource = new EventSource("http://localhost:8080");

eventSource.onmessage = (event) => {
  console.log("Message from server:", event.data);
};


This is a simple implementation. For production, consider handling errors, reconnections, and optimizing performance. Let me know if you'd like further assistance! 😊