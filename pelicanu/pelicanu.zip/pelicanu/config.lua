-- Arquivo de configuracao geral do PELICAnU
-- Utiliza a sintaxe padrao da linguagem Lua 5.4. Codificado em UTF-8
-- ========!! Altere-o com parcimonia !!========

base_dir = "C:\\util\\pelicanu\\"
biblioteca = base_dir .. "biblioteca\\"
projeto = base_dir .. "projeto\\"