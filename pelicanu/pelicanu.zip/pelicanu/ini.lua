-- PELICAnU - Projeto Elétrico, Lógico, Interligação, Controle, Automação & Unifilar
-- Autor: Ezequiel Rabelo de Aguiar - 2023
-- Arquivo de inicialização do PELICAnU, criado automaticamente
-- Utiliza a sintaxe padrao da linguagem Lua 5.4. Codificado em UTF-8
-- ========!! Altere-o com parcimonia !!========

projeto = "C:\\Users\\c055897\\Downloads\\SE_BD3_BC\\SE_BD3_BC"