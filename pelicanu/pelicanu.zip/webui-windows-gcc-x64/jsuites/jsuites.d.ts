/**
 * Official Type definitions for jSuites
 * https://jsuites.net
 */

import { JSuites } from "./types";

declare const jSuites: JSuites;

export default jSuites;
