# W2UI

JavaScript libraty with UI widgets for modern apps. Data table, forms, toolbars, sidebar, tabs, tooltips, popups. All about 115kb (compressed). Ideal for creating complex desktop-like web applications. Integrated with any framework (Vue, React, Angular, etc.)

See http://w2ui.com